# Phase 1: keep rules minimal
