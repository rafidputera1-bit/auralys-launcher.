package com.auralys.launcher.ui.drawer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auralys.launcher.data.AppCategory
import com.auralys.launcher.data.AppInfo
import com.auralys.launcher.data.AppRepository
import com.auralys.launcher.ui.home.AppIconImage

private val DrawerLabel = TextStyle(color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center)

/**
 * Full-screen app drawer: alphabetical, search, categories, recents (apps opened via Auralys),
 * long-press menu (Add to Home / Hide / App info). [progress] is 0..1 (closed..open).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawer(
    progress: () -> Float,
    apps: List<AppInfo>,
    hiddenKeys: Set<String>,
    recentKeys: List<String>,
    repository: AppRepository,
    iconDp: Int,
    showLabels: Boolean,
    onLaunch: (AppInfo, Rect) -> Unit,
    onAddToHome: (AppInfo) -> Unit,
    onHide: (AppInfo) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<AppCategory?>(null) }

    val visible = remember(apps, hiddenKeys) { apps.filter { it.key !in hiddenKeys } }
    val categories = remember(visible) { AppCategory.values().filter { c -> visible.any { it.category == c } } }
    val filtered = remember(visible, query, category) {
        visible.filter { app ->
            (category == null || app.category == category) &&
                (query.isBlank() || app.label.contains(query.trim(), ignoreCase = true))
        }
    }
    val recents = remember(recentKeys, visible) {
        recentKeys.mapNotNull { k -> visible.firstOrNull { it.key == k } }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val p = progress().coerceIn(0f, 1f)
                translationY = (1f - p) * size.height
                alpha = p
            }
            .background(Color(0xE6101015))
            .pointerInput(Unit) { detectTapGestures { } }
            .safeDrawingPadding()
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(16.dp))

            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.16f))
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (query.isEmpty()) {
                    Text("Search apps", color = Color.White.copy(alpha = 0.6f), fontSize = 15.sp)
                }
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(Modifier.height(12.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Chip("All", category == null) { category = null } }
                items(categories) { c -> Chip(c.label, category == c) { category = c } }
            }

            Spacer(Modifier.height(12.dp))

            if (query.isBlank() && category == null && recents.isNotEmpty()) {
                Text("Recent", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recents, key = { it.key }) { app ->
                        DrawerCell(
                            app, repository, iconDp, showLabel = false, onLaunch, onAddToHome, onHide,
                            Modifier.widthIn(min = (iconDp + 24).dp),
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            LazyVerticalGrid(
                columns = GridCells.Adaptive((iconDp + 40).dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(filtered, key = { it.key }) { app ->
                    DrawerCell(app, repository, iconDp, showLabels, onLaunch, onAddToHome, onHide, Modifier)
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (selected) 0.32f else 0.12f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DrawerCell(
    app: AppInfo,
    repository: AppRepository,
    iconDp: Int,
    showLabel: Boolean,
    onLaunch: (AppInfo, Rect) -> Unit,
    onAddToHome: (AppInfo) -> Unit,
    onHide: (AppInfo) -> Unit,
    modifier: Modifier,
) {
    var menu by remember { mutableStateOf(false) }
    var rect by remember { mutableStateOf(Rect.Zero) }

    Box(modifier) {
        Column(
            Modifier
                .fillMaxWidth()
                .onGloballyPositioned { rect = it.boundsInRoot() }
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(onClick = { onLaunch(app, rect) }, onLongClick = { menu = true })
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AppIconImage(app, repository, iconDp.dp)
            if (showLabel) {
                Spacer(Modifier.height(4.dp))
                Text(app.label, style = DrawerLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("Add to Home") }, onClick = { menu = false; onAddToHome(app) })
            DropdownMenuItem(text = { Text("Hide") }, onClick = { menu = false; onHide(app) })
            DropdownMenuItem(text = { Text("App info") }, onClick = { menu = false; repository.openAppInfo(app) })
        }
    }
}
