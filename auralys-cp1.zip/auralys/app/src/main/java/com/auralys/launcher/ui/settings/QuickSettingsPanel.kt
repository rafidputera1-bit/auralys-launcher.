package com.auralys.launcher.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.auralys.launcher.data.AppInfo
import com.auralys.launcher.data.DockLayoutConfig
import com.auralys.launcher.data.GridConfig
import com.auralys.launcher.data.LauncherSettings
import kotlin.math.roundToInt

/**
 * Settings for Home grid + Dock. Every change is previewed live on the real home screen
 * (via [onPreview]); nothing is saved until [onApply]. [onCancel] reverts.
 * Grid and dock size values edit the CURRENT orientation only.
 */
@Composable
fun QuickSettingsPanel(
    initial: LauncherSettings,
    isLandscape: Boolean,
    allApps: List<AppInfo>,
    onPreview: (LauncherSettings) -> Unit,
    onApply: (LauncherSettings) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var draft by remember { mutableStateOf(initial) }
    fun update(s: LauncherSettings) {
        draft = s
        onPreview(s)
    }

    val grid = if (isLandscape) draft.landscapeGrid else draft.portraitGrid
    val dock = if (isLandscape) draft.dockLandscape else draft.dockPortrait
    fun setGrid(g: GridConfig) =
        update(if (isLandscape) draft.copy(landscapeGrid = g) else draft.copy(portraitGrid = g))
    fun setDock(d: DockLayoutConfig) =
        update(if (isLandscape) draft.copy(dockLandscape = d) else draft.copy(dockPortrait = d))

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
        tonalElevation = 6.dp,
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Home & Dock · " + if (isLandscape) "Landscape" else "Portrait",
                    style = MaterialTheme.typography.titleMedium,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onCancel) { Text("Cancel") }
                    Button(onClick = { onApply(draft) }) { Text("Apply") }
                }
            }
            Text(
                "Changes preview live. Tap Apply to keep them.",
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(8.dp))

            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                SectionTitle("Home grid")
                SliderRow("Columns", grid.cols, 3..12) { setGrid(grid.copy(cols = it)) }
                SliderRow("Rows", grid.rows, 3..10) { setGrid(grid.copy(rows = it)) }
                SliderRow("Icon size", draft.iconSizeDp, 40..84, "dp") { update(draft.copy(iconSizeDp = it)) }
                SwitchRow("Show labels", draft.showLabels) { update(draft.copy(showLabels = it)) }

                SectionTitle("Dock")
                SwitchRow("Show dock", draft.dockEnabled) { update(draft.copy(dockEnabled = it)) }
                SliderRow("Icons in dock", draft.dockCount, 3..8) { update(draft.copy(dockCount = it)) }
                SliderRow("Height", dock.heightDp, 56..130, "dp") { setDock(dock.copy(heightDp = it)) }
                SliderRow("Icon size", dock.iconDp, 32..80, "dp") { setDock(dock.copy(iconDp = it)) }
                SwitchRow("Floating dock", draft.dockFloating) { update(draft.copy(dockFloating = it)) }
                if (draft.dockFloating) {
                    SliderRow("Width", dock.widthPercent, 40..100, "%") { setDock(dock.copy(widthPercent = it)) }
                }
                SliderRow("Corner radius", draft.dockCornerDp, 0..48, "dp") { update(draft.copy(dockCornerDp = it)) }
                SliderRow("Background opacity", draft.dockAlphaPct, 0..90, "%") { update(draft.copy(dockAlphaPct = it)) }

                val hidden = allApps.filter { it.key in draft.hiddenKeys }
                if (hidden.isNotEmpty()) {
                    SectionTitle("Hidden apps")
                    hidden.forEach { app ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(app.label)
                            TextButton(onClick = { update(draft.copy(hiddenKeys = draft.hiddenKeys - app.key)) }) {
                                Text("Show")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 14.dp, bottom = 2.dp),
    )
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, suffix: String = "", onChange: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("$value$suffix", style = MaterialTheme.typography.bodyMedium)
        }
        Slider(
            value = value.toFloat().coerceIn(range.first.toFloat(), range.last.toFloat()),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = (range.last - range.first - 1).coerceAtLeast(0),
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
