package com.auralys.launcher.data

import android.content.ComponentName
import android.content.pm.LauncherActivityInfo
import android.os.UserHandle
import androidx.compose.runtime.Immutable

enum class AppCategory(val label: String) {
    GAMES("Games"), SOCIAL("Social"), MEDIA("Media"), PRODUCTIVITY("Productivity"), OTHER("Other")
}

/** One launchable activity. [key] uniquely identifies component + user profile. */
@Immutable
class AppInfo(
    val key: String,
    val label: String,
    val component: ComponentName,
    val user: UserHandle,
    val category: AppCategory,
    internal val source: LauncherActivityInfo,
) {
    override fun equals(other: Any?) = other is AppInfo && other.key == key && other.label == label
    override fun hashCode() = 31 * key.hashCode() + label.hashCode()
}
