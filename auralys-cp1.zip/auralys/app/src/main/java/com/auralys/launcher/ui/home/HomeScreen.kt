package com.auralys.launcher.ui.home

import android.app.ActivityOptions
import android.content.res.Configuration
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.auralys.launcher.data.AppInfo
import com.auralys.launcher.data.DropTarget
import com.auralys.launcher.data.FolderItem
import com.auralys.launcher.data.HomeItem
import com.auralys.launcher.ui.drawer.AppDrawer
import com.auralys.launcher.ui.settings.QuickSettingsPanel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val DrawerSpring = spring<Float>(dampingRatio = 0.85f, stiffness = 380f)

/**
 * Checkpoint-1 home screen: multi-page grid, drag & drop, folders, customizable dock,
 * app drawer (swipe up / "All apps"), and a live-preview settings panel.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(vm: HomeViewModel = viewModel()) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val layout by vm.layout.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val ready by vm.ready.collectAsStateWithLifecycle()

    if (!ready) {
        Box(Modifier.fillMaxSize())
        return
    }

    val context = LocalContext.current
    val view = LocalView.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val grid = if (isLandscape) settings.landscapeGrid else settings.portraitGrid
    val dockCfg = if (isLandscape) settings.dockLandscape else settings.dockPortrait
    val gridNow by rememberUpdatedState(grid)
    val capacity = grid.cols * grid.rows

    val appsByKey = remember(apps) { apps.associateBy { it.key } }
    val dockShown = layout.dock.take(settings.dockCount)

    // ---- UI state ----
    var editMode by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf<HomeItem?>(null) }
    var dragPointer by remember { mutableStateOf(Offset.Zero) }
    var openFolderId by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var gridRect by remember { mutableStateOf(Rect.Zero) }
    var dockRect by remember { mutableStateOf(Rect.Zero) }
    var removeRect by remember { mutableStateOf(Rect.Zero) }

    val drawer = remember { Animatable(0f) }
    val drawerVisible by remember { derivedStateOf { drawer.value > 0.001f } }

    // ---- pager ----
    val extraPage = dragging != null && layout.home.isNotEmpty() && layout.home.size % capacity == 0
    val pageCount = ((layout.home.size + capacity - 1) / capacity).coerceAtLeast(1) + if (extraPage) 1 else 0
    val pagerState = rememberPagerState(pageCount = { pageCount })

    // ---- derived hover flags ----
    val overRemove by remember {
        derivedStateOf { dragging != null && removeRect.contains(dragPointer) }
    }
    val overDock by remember {
        derivedStateOf { dragging != null && settings.dockEnabled && dockRect.contains(dragPointer) }
    }

    // ---- hit-testing (reads current state only) ----
    fun hitItem(p: Offset): HomeItem? {
        val l = vm.layout.value
        val g = gridNow
        if (gridRect.contains(p)) {
            val idx = pagerState.currentPage * g.cols * g.rows + cellIndexAt(p, gridRect, g.cols, g.rows)
            return l.home.getOrNull(idx)
        }
        val s = vm.settings.value
        if (s.dockEnabled && dockRect.contains(p)) {
            val shown = l.dock.take(s.dockCount)
            return shown.getOrNull(dockSlotRaw(p.x, dockRect, s.dockCount, shown.size))
        }
        return null
    }

    fun finishDrag() {
        val item = dragging ?: return
        val p = dragPointer
        dragging = null
        val l = vm.layout.value
        val g = gridNow
        val s = vm.settings.value
        when {
            removeRect.contains(p) -> vm.applyDrop(item.id, DropTarget.Remove)
            s.dockEnabled && dockRect.contains(p) -> {
                val shownSize = l.dock.take(s.dockCount).size
                val slot = dockSlotRaw(p.x, dockRect, s.dockCount, shownSize).coerceIn(0, shownSize)
                vm.applyDrop(item.id, DropTarget.DockIndex(slot))
            }
            gridRect.contains(p) -> {
                val idx = pagerState.currentPage * g.cols * g.rows + cellIndexAt(p, gridRect, g.cols, g.rows)
                val occupied = l.home.getOrNull(idx)
                if (occupied != null && occupied.id != item.id && isCellCenter(p, gridRect, g.cols, g.rows)) {
                    vm.applyDrop(item.id, DropTarget.OntoItem(occupied.id))
                } else {
                    vm.applyDrop(item.id, DropTarget.HomeIndex(idx.coerceAtMost(l.home.size)))
                }
            }
        }
    }

    // ---- page switching while dragging near the left/right edge ----
    val edgePx = with(density) { 40.dp.toPx() }
    val edge by remember {
        derivedStateOf {
            val x = dragPointer.x
            val y = dragPointer.y
            if (dragging == null || gridRect.width <= 0f || y < gridRect.top || y > gridRect.bottom) 0
            else if (x < gridRect.left + edgePx) -1
            else if (x > gridRect.right - edgePx) 1
            else 0
        }
    }
    LaunchedEffect(edge) {
        if (edge != 0) {
            while (true) {
                delay(650)
                val target = pagerState.currentPage + edge
                if (target in 0 until pagerState.pageCount) pagerState.animateScrollToPage(target)
            }
        }
    }

    // ---- Home button / back ----
    LaunchedEffect(Unit) {
        vm.homeEvents.collect {
            dragging = null
            openFolderId = null
            editMode = false
            if (showSettings) {
                vm.revertSettings()
                showSettings = false
            }
            drawer.animateTo(0f, DrawerSpring)
            pagerState.animateScrollToPage(0)
        }
    }
    BackHandler(enabled = openFolderId != null || showSettings || drawerVisible || editMode) {
        when {
            openFolderId != null -> openFolderId = null
            showSettings -> {
                vm.revertSettings()
                showSettings = false
            }
            drawerVisible -> scope.launch { drawer.animateTo(0f, DrawerSpring) }
            editMode -> editMode = false
        }
    }

    // ---- launching with a real scale-up-from-icon transition ----
    val openApp: (AppInfo, Rect) -> Unit = { app, r ->
        if (!editMode) {
            val l = r.left.toInt()
            val t = r.top.toInt()
            val w = r.width.toInt().coerceAtLeast(1)
            val h = r.height.toInt().coerceAtLeast(1)
            val options = ActivityOptions.makeScaleUpAnimation(view, l, t, w, h).toBundle()
            vm.launch(app, android.graphics.Rect(l, t, l + w, t + h), options)
            if (drawerVisible) scope.launch { drawer.snapTo(0f) }
            openFolderId = null
        }
    }
    val openFolder: (FolderItem) -> Unit = { openFolderId = it.folderId }

    val scrimAlpha by animateFloatAsState(if (editMode) 0.25f else 0f, label = "scrim")

    Box(Modifier.fillMaxSize()) {

        // =============== Home layer (gestures live here) ===============
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind { drawRect(Color.Black.copy(alpha = scrimAlpha)) }
                // Long-press: pick up an icon (drag) or enter edit mode on empty space.
                .pointerInput(Unit) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { offset ->
                            if (drawerVisible || openFolderId != null || showSettings) {
                                return@detectDragGesturesAfterLongPress
                            }
                            dragPointer = offset
                            editMode = true
                            dragging = hitItem(offset)
                        },
                        onDrag = { change, _ ->
                            if (dragging != null) {
                                change.consume()
                                dragPointer = change.position
                            }
                        },
                        onDragEnd = { finishDrag() },
                        onDragCancel = { dragging = null },
                    )
                }
                // Swipe up: open the app drawer, following the finger.
                .pointerInput(Unit) {
                    var total = 0f
                    var active = false
                    detectVerticalDragGestures(
                        onDragStart = {
                            active = !(editMode || dragging != null || drawerVisible ||
                                openFolderId != null || showSettings)
                            total = 0f
                        },
                        onDragEnd = {
                            if (active) {
                                scope.launch {
                                    drawer.animateTo(if (drawer.value > 0.25f) 1f else 0f, DrawerSpring)
                                }
                            }
                            active = false
                        },
                        onDragCancel = {
                            if (active) scope.launch { drawer.animateTo(0f, DrawerSpring) }
                            active = false
                        },
                        onVerticalDrag = { change, dy ->
                            if (active) {
                                change.consume()
                                total -= dy
                                val p = (total / (size.height * 0.6f)).coerceIn(0f, 1f)
                                scope.launch { drawer.snapTo(p) }
                            }
                        },
                    )
                }
        ) {
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                Box(
                    Modifier.fillMaxWidth().height(64.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (editMode) {
                        EditBar(
                            overRemove = overRemove,
                            onRemoveRect = { removeRect = it },
                            onSettings = { showSettings = true },
                            onDone = { editMode = false },
                        )
                    } else {
                        SearchPill { scope.launch { drawer.animateTo(1f, DrawerSpring) } }
                    }
                }

                Box(Modifier.weight(1f).padding(horizontal = 20.dp)) {
                    HorizontalPager(
                        state = pagerState,
                        userScrollEnabled = dragging == null,
                        modifier = Modifier
                            .fillMaxSize()
                            .onGloballyPositioned { gridRect = it.boundsInRoot() },
                    ) { page ->
                        val pageItems = layout.home.drop(page * capacity).take(capacity)
                        HomePage(
                            pageItems = pageItems,
                            cols = grid.cols,
                            rows = grid.rows,
                            iconDp = settings.iconSizeDp,
                            showLabels = settings.showLabels,
                            appsByKey = appsByKey,
                            repository = vm.repository,
                            draggingId = dragging?.id,
                            onOpenApp = openApp,
                            onOpenFolder = openFolder,
                        )
                    }
                }

                PageIndicator(
                    count = pageCount,
                    current = pagerState.currentPage,
                    onOpenDrawer = { scope.launch { drawer.animateTo(1f, DrawerSpring) } },
                )

                if (settings.dockEnabled) {
                    Dock(
                        items = dockShown,
                        slots = settings.dockCount,
                        appsByKey = appsByKey,
                        repository = vm.repository,
                        settings = settings,
                        cfg = dockCfg,
                        draggingId = dragging?.id,
                        highlight = overDock,
                        onOpenApp = openApp,
                        onOpenFolder = openFolder,
                        onRectChanged = { dockRect = it },
                    )
                } else {
                    dockRect = Rect.Zero
                }
            }
        }

        // =============== Overlays ===============
        dragging?.let { item ->
            DragOverlay(
                item = item,
                pointerProvider = { dragPointer },
                appsByKey = appsByKey,
                repository = vm.repository,
                iconDp = settings.iconSizeDp,
            )
        }

        val openFolderItem = openFolderId?.let { id ->
            (layout.home + layout.dock).firstOrNull { it is FolderItem && it.folderId == id } as? FolderItem
        }
        LaunchedEffect(openFolderId, openFolderItem) {
            if (openFolderId != null && openFolderItem == null) openFolderId = null
        }
        if (openFolderItem != null) {
            FolderOverlay(
                folder = openFolderItem,
                appsByKey = appsByKey,
                repository = vm.repository,
                iconDp = settings.iconSizeDp,
                onLaunch = openApp,
                onTakeOut = { key -> vm.removeFromFolder(openFolderItem.folderId, key) },
                onRename = { name -> vm.renameFolder(openFolderItem.folderId, name) },
                onClose = { openFolderId = null },
            )
        }

        if (drawerVisible) {
            AppDrawer(
                progress = { drawer.value },
                apps = apps,
                hiddenKeys = settings.hiddenKeys,
                recentKeys = settings.recentKeys,
                repository = vm.repository,
                iconDp = settings.iconSizeDp,
                showLabels = settings.showLabels,
                onLaunch = openApp,
                onAddToHome = { app ->
                    val added = vm.addToHome(app)
                    Toast.makeText(
                        context,
                        if (added) "Added to Home" else "Already on Home",
                        Toast.LENGTH_SHORT,
                    ).show()
                },
                onHide = { app -> vm.hideApp(app.key) },
            )
        }

        if (showSettings) {
            Box(Modifier.fillMaxSize().safeDrawingPadding()) {
                QuickSettingsPanel(
                    initial = settings,
                    isLandscape = isLandscape,
                    allApps = apps,
                    onPreview = { vm.previewSettings(it) },
                    onApply = {
                        vm.commitSettings(it)
                        showSettings = false
                    },
                    onCancel = {
                        vm.revertSettings()
                        showSettings = false
                    },
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .fillMaxHeight(0.5f)
                        .padding(12.dp),
                )
            }
        }
    }
}
