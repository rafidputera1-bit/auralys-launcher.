package com.auralys.launcher.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.graphics.Rect
import android.os.Bundle
import android.os.UserHandle
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

/**
 * Reads launchable apps through [LauncherApps] (no QUERY_ALL_PACKAGES needed)
 * and re-emits whenever packages are added/removed/changed.
 */
class AppRepository(context: Context) {

    private val appContext = context.applicationContext
    private val launcherApps =
        appContext.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps

    private val iconCache = LruCache<String, ImageBitmap>(300)
    private val iconSizePx = (appContext.resources.displayMetrics.density * 72).toInt()

    private val collator = Collator.getInstance(Locale.getDefault()).apply {
        strength = Collator.PRIMARY
    }

    fun observeApps(): Flow<List<AppInfo>> = callbackFlow {
        val callback = object : LauncherApps.Callback() {
            private fun refresh() { trySend(loadApps()) }
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackageAdded(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackageChanged(packageName: String?, user: UserHandle?) = refresh()
            override fun onPackagesAvailable(
                packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
            ) = refresh()
            override fun onPackagesUnavailable(
                packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
            ) = refresh()
        }
        launcherApps.registerCallback(callback)
        trySend(loadApps())
        awaitClose { launcherApps.unregisterCallback(callback) }
    }.flowOn(Dispatchers.Default)

    private fun mapCategory(c: Int): AppCategory = when (c) {
        ApplicationInfo.CATEGORY_GAME -> AppCategory.GAMES
        ApplicationInfo.CATEGORY_SOCIAL -> AppCategory.SOCIAL
        ApplicationInfo.CATEGORY_AUDIO,
        ApplicationInfo.CATEGORY_VIDEO,
        ApplicationInfo.CATEGORY_IMAGE -> AppCategory.MEDIA
        ApplicationInfo.CATEGORY_PRODUCTIVITY,
        ApplicationInfo.CATEGORY_NEWS -> AppCategory.PRODUCTIVITY
        else -> AppCategory.OTHER
    }

    private fun loadApps(): List<AppInfo> {
        val own = appContext.packageName
        return launcherApps.profiles
            .flatMap { user -> launcherApps.getActivityList(null, user) }
            .filter { it.componentName.packageName != own }
            .map { info ->
                AppInfo(
                    key = info.componentName.flattenToString() + "#" + info.user.hashCode(),
                    label = info.label?.toString().orEmpty(),
                    component = info.componentName,
                    user = info.user,
                    category = mapCategory(info.applicationInfo.category),
                    source = info,
                )
            }
            .sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    fun cachedIcon(app: AppInfo): ImageBitmap? = iconCache.get(app.key)

    suspend fun icon(app: AppInfo): ImageBitmap = withContext(Dispatchers.Default) {
        iconCache.get(app.key) ?: run {
            val bmp = app.source.getIcon(0).toBitmap(iconSizePx, iconSizePx).asImageBitmap()
            iconCache.put(app.key, bmp)
            bmp
        }
    }

    fun launch(app: AppInfo, sourceBounds: Rect?, options: Bundle?) {
        try {
            launcherApps.startMainActivity(app.component, app.user, sourceBounds, options)
        } catch (_: Exception) {
            // App may have been uninstalled/disabled between list load and tap.
        }
    }

    fun openAppInfo(app: AppInfo) {
        try {
            launcherApps.startAppDetailsActivity(app.component, app.user, null, null)
        } catch (_: Exception) {
        }
    }
}
