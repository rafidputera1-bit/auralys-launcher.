package com.auralys.launcher.data

/** Something that can sit on the home screen or in the dock. */
sealed interface HomeItem { val id: String }

data class AppItem(val appKey: String) : HomeItem {
    override val id: String get() = "a:$appKey"
}

data class FolderItem(val folderId: String, val name: String, val appKeys: List<String>) : HomeItem {
    override val id: String get() = "f:$folderId"
}

data class GridConfig(val cols: Int, val rows: Int)

/** Dock dimensions that can differ between portrait and landscape. */
data class DockLayoutConfig(val heightDp: Int, val iconDp: Int, val widthPercent: Int)

data class LauncherSettings(
    val portraitGrid: GridConfig = GridConfig(5, 6),
    val landscapeGrid: GridConfig = GridConfig(8, 4),
    val iconSizeDp: Int = 56,
    val showLabels: Boolean = true,
    val dockEnabled: Boolean = true,
    val dockCount: Int = 5,
    val dockPortrait: DockLayoutConfig = DockLayoutConfig(heightDp = 92, iconDp = 54, widthPercent = 92),
    val dockLandscape: DockLayoutConfig = DockLayoutConfig(heightDp = 84, iconDp = 50, widthPercent = 60),
    val dockCornerDp: Int = 30,
    val dockAlphaPct: Int = 30,
    val dockFloating: Boolean = true,
    val hiddenKeys: Set<String> = emptySet(),
    val recentKeys: List<String> = emptyList(),
)

/**
 * Home items are a flat ordered list; pages are derived by chunking that list by the
 * current grid capacity, so layouts reflow cleanly between portrait and landscape.
 */
data class LauncherLayout(val home: List<HomeItem>, val dock: List<HomeItem>)

sealed interface DropTarget {
    data class HomeIndex(val index: Int) : DropTarget
    data class DockIndex(val index: Int) : DropTarget
    data class OntoItem(val itemId: String) : DropTarget
    data object Remove : DropTarget
}
