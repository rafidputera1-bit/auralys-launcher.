package com.auralys.launcher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.auralysStore: DataStore<Preferences> by preferencesDataStore(name = "auralys")

/** Persists launcher layout and settings (DataStore, JSON strings). */
class LauncherStore(context: Context) {
    private val ds = context.applicationContext.auralysStore
    private val layoutKey = stringPreferencesKey("layout")
    private val settingsKey = stringPreferencesKey("settings")

    suspend fun loadLayout(): LauncherLayout? =
        ds.data.first()[layoutKey]?.let { Codec.decodeLayout(it) }

    suspend fun loadSettings(): LauncherSettings =
        ds.data.first()[settingsKey]?.let { Codec.decodeSettings(it) } ?: LauncherSettings()

    suspend fun saveLayout(l: LauncherLayout) {
        ds.edit { it[layoutKey] = Codec.encodeLayout(l) }
    }

    suspend fun saveSettings(s: LauncherSettings) {
        ds.edit { it[settingsKey] = Codec.encodeSettings(s) }
    }
}
