package com.auralys.launcher.ui.home

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.auralys.launcher.data.AppInfo
import com.auralys.launcher.data.AppItem
import com.auralys.launcher.data.AppRepository
import com.auralys.launcher.data.DropTarget
import com.auralys.launcher.data.FolderItem
import com.auralys.launcher.data.HomeItem
import com.auralys.launcher.data.LauncherLayout
import com.auralys.launcher.data.LauncherSettings
import com.auralys.launcher.data.LauncherStore
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    val repository = AppRepository(app)
    private val store = LauncherStore(app)

    val apps: StateFlow<List<AppInfo>> =
        repository.observeApps().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _layout = MutableStateFlow(LauncherLayout(emptyList(), emptyList()))
    val layout: StateFlow<LauncherLayout> = _layout.asStateFlow()

    private val _settings = MutableStateFlow(LauncherSettings())
    val settings: StateFlow<LauncherSettings> = _settings.asStateFlow()
    private var committed = LauncherSettings()

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _homeEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val homeEvents: SharedFlow<Unit> = _homeEvents.asSharedFlow()

    init {
        viewModelScope.launch {
            committed = store.loadSettings()
            _settings.value = committed
            val saved = store.loadLayout()
            val list = apps.first { it.isNotEmpty() }
            _layout.value = saved ?: seed(list).also { store.saveLayout(it) }
            _ready.value = true
            apps.collect { current -> if (current.isNotEmpty()) prune(current) }
        }
    }

    fun onHomePressed() { _homeEvents.tryEmit(Unit) }

    // ---------- first-run layout ----------
    private fun seed(list: List<AppInfo>): LauncherLayout {
        val pm = getApplication<Application>().packageManager
        fun pkgFor(intent: Intent): String? =
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName

        val dockPkgs = listOfNotNull(
            pkgFor(Intent(Intent.ACTION_DIAL)),
            pkgFor(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            pkgFor(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
            pkgFor(Intent(MediaStore.ACTION_IMAGE_CAPTURE)),
            pkgFor(Intent(Settings.ACTION_SETTINGS)),
        ).distinct()

        val dockApps = dockPkgs
            .mapNotNull { pkg -> list.firstOrNull { it.component.packageName == pkg } }
            .distinctBy { it.key }
            .take(_settings.value.dockCount)
        val dockKeys = dockApps.map { it.key }.toSet()
        val homeApps = list.filter { it.key !in dockKeys }.take(12)

        return LauncherLayout(
            home = homeApps.map { AppItem(it.key) },
            dock = dockApps.map { AppItem(it.key) },
        )
    }

    /** Remove entries whose app no longer exists (uninstalled). */
    private fun prune(list: List<AppInfo>) {
        val keys = list.mapTo(HashSet()) { it.key }
        fun fix(items: List<HomeItem>): List<HomeItem> = items.flatMap { item ->
            when (item) {
                is AppItem ->
                    if (item.appKey in keys) listOf<HomeItem>(item) else emptyList<HomeItem>()
                is FolderItem -> {
                    val rest = item.appKeys.filter { it in keys }
                    when {
                        rest.isEmpty() -> emptyList<HomeItem>()
                        rest.size == 1 -> listOf<HomeItem>(AppItem(rest[0]))
                        else -> listOf<HomeItem>(item.copy(appKeys = rest))
                    }
                }
            }
        }
        val cur = _layout.value
        val home = fix(cur.home)
        val dock = fix(cur.dock)
        if (home != cur.home || dock != cur.dock) updateLayout { it.copy(home = home, dock = dock) }
    }

    private fun updateLayout(block: (LauncherLayout) -> LauncherLayout) {
        val next = block(_layout.value)
        _layout.value = next
        viewModelScope.launch { store.saveLayout(next) }
    }

    private fun newId() = UUID.randomUUID().toString().take(8)

    private fun LauncherLayout.isPlaced(key: String): Boolean =
        (home + dock).any { (it is AppItem && it.appKey == key) || (it is FolderItem && key in it.appKeys) }

    // ---------- launching ----------
    fun launch(app: AppInfo, bounds: Rect?, options: Bundle?) {
        repository.launch(app, bounds, options)
        val recents = (listOf(app.key) + committed.recentKeys.filter { it != app.key }).take(8)
        committed = committed.copy(recentKeys = recents)
        _settings.value = _settings.value.copy(recentKeys = recents)
        viewModelScope.launch { store.saveSettings(committed) }
    }

    // ---------- layout editing ----------
    /** Returns true if the app was added (false if it is already on Home/Dock/folder). */
    fun addToHome(app: AppInfo): Boolean {
        if (_layout.value.isPlaced(app.key)) return false
        updateLayout { it.copy(home = it.home + AppItem(app.key)) }
        return true
    }

    /**
     * Indices are relative to the lists as displayed, i.e. still containing the dragged item.
     * Dropping on [DropTarget.OntoItem] merges into a folder.
     */
    fun applyDrop(dragId: String, target: DropTarget) {
        val cur = _layout.value
        val home = cur.home.toMutableList()
        val dock = cur.dock.toMutableList()
        val dragged = home.firstOrNull { it.id == dragId } ?: dock.firstOrNull { it.id == dragId } ?: return
        val oldHome = home.indexOfFirst { it.id == dragId }
        val oldDock = dock.indexOfFirst { it.id == dragId }
        home.removeAll { it.id == dragId }
        dock.removeAll { it.id == dragId }

        when (target) {
            DropTarget.Remove -> Unit
            is DropTarget.HomeIndex -> {
                var i = target.index
                if (oldHome in 0 until i) i -= 1
                home.add(i.coerceIn(0, home.size), dragged)
            }
            is DropTarget.DockIndex -> {
                if (dock.size >= _settings.value.dockCount) return
                var i = target.index
                if (oldDock in 0 until i) i -= 1
                dock.add(i.coerceIn(0, dock.size), dragged)
            }
            is DropTarget.OntoItem -> {
                val list = if (home.any { it.id == target.itemId }) home else dock
                val idx = list.indexOfFirst { it.id == target.itemId }
                if (idx < 0) return
                val t = list[idx]
                when {
                    t is FolderItem && dragged is AppItem ->
                        list[idx] = t.copy(appKeys = t.appKeys + dragged.appKey)
                    t is AppItem && dragged is AppItem ->
                        list[idx] = FolderItem(newId(), "Folder", listOf(t.appKey, dragged.appKey))
                    else -> list.add(idx, dragged)
                }
            }
        }
        updateLayout { it.copy(home = home, dock = dock) }
    }

    fun removeFromFolder(folderId: String, appKey: String) = updateLayout { l ->
        fun fix(list: List<HomeItem>): List<HomeItem> = list.flatMap { item ->
            if (item is FolderItem && item.folderId == folderId) {
                val rest = item.appKeys - appKey
                when (rest.size) {
                    0 -> emptyList<HomeItem>()
                    1 -> listOf<HomeItem>(AppItem(rest[0]))
                    else -> listOf<HomeItem>(item.copy(appKeys = rest))
                }
            } else listOf(item)
        }
        l.copy(home = fix(l.home) + AppItem(appKey), dock = fix(l.dock))
    }

    fun renameFolder(folderId: String, name: String) {
        val clean = name.trim().ifEmpty { "Folder" }
        val changed = (_layout.value.home + _layout.value.dock)
            .any { it is FolderItem && it.folderId == folderId && it.name != clean }
        if (!changed) return
        updateLayout { l ->
            fun ren(list: List<HomeItem>) = list.map {
                if (it is FolderItem && it.folderId == folderId) it.copy(name = clean) else it
            }
            l.copy(home = ren(l.home), dock = ren(l.dock))
        }
    }

    // ---------- settings (preview before apply) ----------
    fun previewSettings(s: LauncherSettings) { _settings.value = s }

    fun revertSettings() { _settings.value = committed }

    fun commitSettings(s: LauncherSettings) {
        // keep recents from the live state
        val merged = s.copy(recentKeys = committed.recentKeys)
        committed = merged
        _settings.value = merged
        viewModelScope.launch { store.saveSettings(merged) }
    }

    fun hideApp(key: String) = commitSettings(_settings.value.copy(hiddenKeys = _settings.value.hiddenKeys + key))
}
