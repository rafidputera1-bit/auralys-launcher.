package com.auralys.launcher.data

import org.json.JSONArray
import org.json.JSONObject

/** JSON (de)serialization for layout + settings. Tolerant of missing fields. */
object Codec {

    private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }

    private fun itemToJson(i: HomeItem): JSONObject {
        val o = JSONObject()
        when (i) {
            is AppItem -> {
                o.put("t", "a")
                o.put("k", i.appKey)
            }
            is FolderItem -> {
                o.put("t", "f")
                o.put("id", i.folderId)
                o.put("n", i.name)
                o.put("k", JSONArray(i.appKeys))
            }
        }
        return o
    }

    private fun itemFromJson(o: JSONObject): HomeItem? = when (o.optString("t")) {
        "a" -> AppItem(o.getString("k"))
        "f" -> FolderItem(o.getString("id"), o.optString("n", "Folder"), o.getJSONArray("k").strings())
        else -> null
    }

    private fun itemsToJson(list: List<HomeItem>): JSONArray {
        val a = JSONArray()
        list.forEach { a.put(itemToJson(it)) }
        return a
    }

    private fun itemsFromJson(a: JSONArray?): List<HomeItem> =
        if (a == null) emptyList()
        else (0 until a.length()).mapNotNull { itemFromJson(a.getJSONObject(it)) }

    fun encodeLayout(l: LauncherLayout): String =
        JSONObject().put("home", itemsToJson(l.home)).put("dock", itemsToJson(l.dock)).toString()

    fun decodeLayout(s: String): LauncherLayout? = try {
        val o = JSONObject(s)
        LauncherLayout(itemsFromJson(o.optJSONArray("home")), itemsFromJson(o.optJSONArray("dock")))
    } catch (e: Exception) {
        null
    }

    fun encodeSettings(s: LauncherSettings): String {
        val o = JSONObject()
        o.put("pgC", s.portraitGrid.cols); o.put("pgR", s.portraitGrid.rows)
        o.put("lgC", s.landscapeGrid.cols); o.put("lgR", s.landscapeGrid.rows)
        o.put("icon", s.iconSizeDp); o.put("labels", s.showLabels)
        o.put("dockOn", s.dockEnabled); o.put("dockN", s.dockCount)
        o.put("dpH", s.dockPortrait.heightDp); o.put("dpI", s.dockPortrait.iconDp); o.put("dpW", s.dockPortrait.widthPercent)
        o.put("dlH", s.dockLandscape.heightDp); o.put("dlI", s.dockLandscape.iconDp); o.put("dlW", s.dockLandscape.widthPercent)
        o.put("dockR", s.dockCornerDp); o.put("dockA", s.dockAlphaPct); o.put("dockF", s.dockFloating)
        o.put("hidden", JSONArray(s.hiddenKeys.toList()))
        o.put("recent", JSONArray(s.recentKeys))
        return o.toString()
    }

    fun decodeSettings(str: String): LauncherSettings = try {
        val o = JSONObject(str)
        val d = LauncherSettings()
        d.copy(
            portraitGrid = GridConfig(o.optInt("pgC", d.portraitGrid.cols), o.optInt("pgR", d.portraitGrid.rows)),
            landscapeGrid = GridConfig(o.optInt("lgC", d.landscapeGrid.cols), o.optInt("lgR", d.landscapeGrid.rows)),
            iconSizeDp = o.optInt("icon", d.iconSizeDp),
            showLabels = o.optBoolean("labels", d.showLabels),
            dockEnabled = o.optBoolean("dockOn", d.dockEnabled),
            dockCount = o.optInt("dockN", d.dockCount),
            dockPortrait = DockLayoutConfig(
                o.optInt("dpH", d.dockPortrait.heightDp),
                o.optInt("dpI", d.dockPortrait.iconDp),
                o.optInt("dpW", d.dockPortrait.widthPercent),
            ),
            dockLandscape = DockLayoutConfig(
                o.optInt("dlH", d.dockLandscape.heightDp),
                o.optInt("dlI", d.dockLandscape.iconDp),
                o.optInt("dlW", d.dockLandscape.widthPercent),
            ),
            dockCornerDp = o.optInt("dockR", d.dockCornerDp),
            dockAlphaPct = o.optInt("dockA", d.dockAlphaPct),
            dockFloating = o.optBoolean("dockF", d.dockFloating),
            hiddenKeys = o.optJSONArray("hidden")?.strings()?.toSet() ?: emptySet(),
            recentKeys = o.optJSONArray("recent")?.strings() ?: emptyList(),
        )
    } catch (e: Exception) {
        LauncherSettings()
    }
}
