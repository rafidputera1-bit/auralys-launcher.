package com.auralys.launcher.ui.home

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.auralys.launcher.data.AppInfo
import com.auralys.launcher.data.AppItem
import com.auralys.launcher.data.AppRepository
import com.auralys.launcher.data.DockLayoutConfig
import com.auralys.launcher.data.FolderItem
import com.auralys.launcher.data.HomeItem
import com.auralys.launcher.data.LauncherSettings
import kotlin.math.floor
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------
// Geometry helpers (pure functions, used by drag & drop hit-testing)
// ---------------------------------------------------------------------------------------------

/** Index (row * cols + col) of the grid cell under [p] inside [rect]. */
internal fun cellIndexAt(p: Offset, rect: Rect, cols: Int, rows: Int): Int {
    val cw = rect.width / cols
    val ch = rect.height / rows
    val col = ((p.x - rect.left) / cw).toInt().coerceIn(0, cols - 1)
    val row = ((p.y - rect.top) / ch).toInt().coerceIn(0, rows - 1)
    return row * cols + col
}

/** True when [p] is in the central part of its cell (used to decide "merge into folder"). */
internal fun isCellCenter(p: Offset, rect: Rect, cols: Int, rows: Int): Boolean {
    val fx = ((p.x - rect.left) / (rect.width / cols)) % 1f
    val fy = ((p.y - rect.top) / (rect.height / rows)) % 1f
    return fx in 0.25f..0.75f && fy in 0.25f..0.75f
}

/** Raw (unclamped) dock slot under x, for a centered group of [itemCount] items in [slots] slots. */
internal fun dockSlotRaw(x: Float, rect: Rect, slots: Int, itemCount: Int): Int {
    val slotW = rect.width / slots
    val start = rect.left + (rect.width - itemCount * slotW) / 2f
    return floor((x - start) / slotW).toInt()
}

// ---------------------------------------------------------------------------------------------
// Icons
// ---------------------------------------------------------------------------------------------

internal class BoundsHolder { var rect: Rect = Rect.Zero }

private val LabelStyle = TextStyle(
    fontSize = 12.sp,
    color = Color.White,
    textAlign = TextAlign.Center,
    shadow = Shadow(color = Color.Black.copy(alpha = 0.45f), offset = Offset(0f, 1f), blurRadius = 4f),
)

@Composable
internal fun AppIconImage(app: AppInfo, repository: AppRepository, size: Dp, modifier: Modifier = Modifier) {
    val icon: ImageBitmap? by produceState(repository.cachedIcon(app), app.key) {
        value = repository.icon(app)
    }
    val bmp = icon
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = app.label, modifier = modifier.size(size))
    } else {
        Box(modifier.size(size).clip(RoundedCornerShape(size * 0.25f)).background(Color.White.copy(alpha = 0.15f)))
    }
}

@Composable
internal fun FolderIcon(
    folder: FolderItem,
    appsByKey: Map<String, AppInfo>,
    repository: AppRepository,
    size: Dp,
) {
    val apps = folder.appKeys.mapNotNull { appsByKey[it] }.take(4)
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(Color.White.copy(alpha = 0.22f))
            .padding(size * 0.1f)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
            apps.chunked(2).forEach { rowApps ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    rowApps.forEach { AppIconImage(it, repository, size * 0.36f) }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun ItemView(
    item: HomeItem,
    appsByKey: Map<String, AppInfo>,
    repository: AppRepository,
    iconDp: Int,
    showLabel: Boolean,
    onOpenApp: (AppInfo, Rect) -> Unit,
    onOpenFolder: (FolderItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val holder = remember { BoundsHolder() }
    val app = (item as? AppItem)?.let { appsByKey[it.appKey] }
    if (item is AppItem && app == null) return

    Column(
        modifier = modifier
            .onGloballyPositioned { holder.rect = it.boundsInRoot() }
            .clip(RoundedCornerShape(18.dp))
            .clickable {
                when (item) {
                    is AppItem -> if (app != null) onOpenApp(app, holder.rect)
                    is FolderItem -> onOpenFolder(item)
                }
            }
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        when (item) {
            is AppItem -> if (app != null) AppIconImage(app, repository, iconDp.dp)
            is FolderItem -> FolderIcon(item, appsByKey, repository, iconDp.dp)
        }
        if (showLabel) {
            Spacer(Modifier.height(4.dp))
            val label = when (item) {
                is AppItem -> app?.label.orEmpty()
                is FolderItem -> item.name
            }
            Text(text = label, style = LabelStyle, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Home page (grid with animated icon movement)
// ---------------------------------------------------------------------------------------------

@Composable
internal fun HomePage(
    pageItems: List<HomeItem>,
    cols: Int,
    rows: Int,
    iconDp: Int,
    showLabels: Boolean,
    appsByKey: Map<String, AppInfo>,
    repository: AppRepository,
    draggingId: String?,
    onOpenApp: (AppInfo, Rect) -> Unit,
    onOpenFolder: (FolderItem) -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cellWpx = constraints.maxWidth / cols
        val cellHpx = constraints.maxHeight / rows
        val cellW = with(LocalDensity.current) { cellWpx.toDp() }
        val cellH = with(LocalDensity.current) { cellHpx.toDp() }

        pageItems.forEachIndexed { i, item ->
            key(item.id) {
                val target = IntOffset((i % cols) * cellWpx, (i / cols) * cellHpx)
                val animOffset by animateIntOffsetAsState(
                    targetValue = target,
                    animationSpec = spring(dampingRatio = 0.8f, stiffness = 300f),
                    label = "cell",
                )
                val hidden = item.id == draggingId
                Box(
                    Modifier
                        .offset { animOffset }
                        .size(cellW, cellH)
                        .graphicsLayer { alpha = if (hidden) 0.25f else 1f }
                ) {
                    ItemView(
                        item = item,
                        appsByKey = appsByKey,
                        repository = repository,
                        iconDp = iconDp,
                        showLabel = showLabels,
                        onOpenApp = onOpenApp,
                        onOpenFolder = onOpenFolder,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Dock
// ---------------------------------------------------------------------------------------------

@Composable
internal fun Dock(
    items: List<HomeItem>,
    slots: Int,
    appsByKey: Map<String, AppInfo>,
    repository: AppRepository,
    settings: LauncherSettings,
    cfg: DockLayoutConfig,
    draggingId: String?,
    highlight: Boolean,
    onOpenApp: (AppInfo, Rect) -> Unit,
    onOpenFolder: (FolderItem) -> Unit,
    onRectChanged: (Rect) -> Unit,
    modifier: Modifier = Modifier,
) {
    val floating = settings.dockFloating
    val shape = if (floating) RoundedCornerShape(settings.dockCornerDp.dp)
    else RoundedCornerShape(topStart = settings.dockCornerDp.dp, topEnd = settings.dockCornerDp.dp)
    val borderColor = Color.White.copy(alpha = if (highlight) 0.85f else 0.25f)

    Box(
        modifier
            .fillMaxWidth()
            .padding(bottom = if (floating) 12.dp else 0.dp),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Row(
            Modifier
                .fillMaxWidth(if (floating) cfg.widthPercent / 100f else 1f)
                .height(cfg.heightDp.dp)
                .onGloballyPositioned { onRectChanged(it.boundsInRoot()) }
                .clip(shape)
                .background(Color.White.copy(alpha = settings.dockAlphaPct / 100f))
                .border(if (highlight) 2.dp else 1.dp, borderColor, shape),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val spare = slots - items.size
            if (spare > 0) Spacer(Modifier.weight(spare / 2f))
            items.forEach { item ->
                key(item.id) {
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .graphicsLayer { alpha = if (item.id == draggingId) 0.25f else 1f },
                        contentAlignment = Alignment.Center,
                    ) {
                        ItemView(
                            item = item,
                            appsByKey = appsByKey,
                            repository = repository,
                            iconDp = cfg.iconDp,
                            showLabel = false,
                            onOpenApp = onOpenApp,
                            onOpenFolder = onOpenFolder,
                            modifier = Modifier,
                        )
                    }
                }
            }
            if (spare > 0) Spacer(Modifier.weight(spare / 2f))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Top bars, indicator, drag overlay
// ---------------------------------------------------------------------------------------------

@Composable
internal fun GlassButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.22f))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 14.sp)
    }
}

@Composable
internal fun SearchPill(onClick: () -> Unit) {
    Box(
        Modifier
            .widthIn(max = 520.dp)
            .fillMaxWidth(0.8f)
            .height(44.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.2f))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Text("Search apps", color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp)
    }
}

@Composable
internal fun EditBar(
    overRemove: Boolean,
    onRemoveRect: (Rect) -> Unit,
    onSettings: () -> Unit,
    onDone: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        GlassButton("Settings", onSettings)
        Box(
            Modifier
                .weight(1f)
                .height(44.dp)
                .onGloballyPositioned { onRemoveRect(it.boundsInRoot()) }
                .clip(CircleShape)
                .background(if (overRemove) Color(0xCCFF5252) else Color.White.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center,
        ) {
            Text("Drop here to remove from Home", color = Color.White, fontSize = 12.sp, maxLines = 1)
        }
        GlassButton("Done", onDone)
    }
}

@Composable
internal fun PageIndicator(count: Int, current: Int, onOpenDrawer: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(36.dp)) {
        Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
            repeat(count) { i ->
                val selected = i == current
                Box(
                    Modifier
                        .padding(3.dp)
                        .size(if (selected) 8.dp else 6.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = if (selected) 0.95f else 0.4f))
                )
            }
        }
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 24.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.2f))
                .clickable(onClick = onOpenDrawer)
                .padding(horizontal = 14.dp, vertical = 4.dp)
        ) {
            Text("All apps", color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
internal fun DragOverlay(
    item: HomeItem,
    pointerProvider: () -> Offset,
    appsByKey: Map<String, AppInfo>,
    repository: AppRepository,
    iconDp: Int,
) {
    Box(
        Modifier
            .offset {
                val p = pointerProvider()
                val half = (iconDp.dp / 2).toPx()
                IntOffset((p.x - half).roundToInt(), (p.y - half).roundToInt())
            }
            .size(iconDp.dp)
            .graphicsLayer {
                scaleX = 1.2f
                scaleY = 1.2f
                alpha = 0.95f
            }
    ) {
        when (item) {
            is AppItem -> appsByKey[item.appKey]?.let { AppIconImage(it, repository, iconDp.dp) }
            is FolderItem -> FolderIcon(item, appsByKey, repository, iconDp.dp)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Folder overlay
// ---------------------------------------------------------------------------------------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FolderOverlay(
    folder: FolderItem,
    appsByKey: Map<String, AppInfo>,
    repository: AppRepository,
    iconDp: Int,
    onLaunch: (AppInfo, Rect) -> Unit,
    onTakeOut: (String) -> Unit,
    onRename: (String) -> Unit,
    onClose: () -> Unit,
) {
    var name by remember(folder.folderId) { mutableStateOf(folder.name) }
    val nameNow by rememberUpdatedState(name)
    val onRenameNow by rememberUpdatedState(onRename)
    DisposableEffect(folder.folderId) { onDispose { onRenameNow(nameNow) } }

    val scale = remember { Animatable(0.85f) }
    LaunchedEffect(Unit) { scale.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = 400f)) }

    val apps = folder.appKeys.mapNotNull { appsByKey[it] }
    val noRipple = remember { MutableInteractionSource() }
    val noRipple2 = remember { MutableInteractionSource() }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(interactionSource = noRipple, indication = null) { onClose() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .graphicsLayer { scaleX = scale.value; scaleY = scale.value; alpha = scale.value.coerceIn(0f, 1f) }
                .widthIn(max = 460.dp)
                .fillMaxWidth(0.88f)
                .clip(RoundedCornerShape(32.dp))
                .background(Color(0xEE1E1E26))
                .clickable(interactionSource = noRipple2, indication = null) { }
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BasicTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 20.sp, textAlign = TextAlign.Center),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.heightIn(max = 360.dp),
            ) {
                items(apps, key = { it.key }) { app ->
                    val holder = remember { BoundsHolder() }
                    Column(
                        Modifier
                            .height(100.dp)
                            .onGloballyPositioned { holder.rect = it.boundsInRoot() }
                            .clip(RoundedCornerShape(16.dp))
                            .combinedClickable(
                                onClick = { onLaunch(app, holder.rect) },
                                onLongClick = { onTakeOut(app.key) },
                            )
                            .padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        AppIconImage(app, repository, iconDp.dp)
                        Spacer(Modifier.height(4.dp))
                        Text(app.label, style = LabelStyle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Text(
                "Long-press an app to take it out of the folder",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 10.dp),
            )
        }
    }
}
