# Auralys Launcher — Checkpoint 1 (Fase 1–3)

## Build tanpa Android Studio (GitHub Actions)
1. Buat repo GitHub baru, upload seluruh isi folder ini (termasuk folder `.github`).
2. Tab Actions > "Build APK" > Run workflow.
3. Setelah hijau, buka run tersebut > Artifacts > unduh `auralys-debug-apk`.
4. Ekstrak zip, pasang `app-debug.apk` di tablet (izinkan "Install unknown apps").
5. Tekan Home > pilih Auralys > "Selalu".

## Fitur di checkpoint ini
- Home multi-halaman (halaman dibuat otomatis dari daftar ikon), indikator halaman
- Long-press ikon: drag & drop (pindah, ke dock, antar halaman lewat tepi layar, hapus dari Home)
- Taruh ikon di atas ikon lain: jadi folder (buka, ganti nama, keluarkan app dengan long-press)
- Dock kustom: jumlah ikon, tinggi, lebar, radius, transparansi, ukuran ikon, floating, beda potret/lanskap
- App drawer: swipe naik / tombol "All apps" / kolom search; urut abjad, pencarian, kategori,
  terbaru, menu long-press (Add to Home / Hide / App info)
- Panel Settings (long-press layar kosong > Settings): preview langsung, baru disimpan saat Apply
- Animasi: ikon bergeser dengan spring, drawer mengikuti jari, scale-up dari ikon saat buka app
- Penyimpanan: DataStore (layout + pengaturan)

## Batasan yang disengaja (akan dibahas di checkpoint berikutnya)
- Posisi ikon berupa urutan (flow), bukan posisi bebas per sel.
- Drag dari drawer ke Home belum ada; pakai menu "Add to Home".
- Dock hanya di bawah. Widget, preset animasi, gesture lain, tema, backup: checkpoint 2–3.
- "Recent" hanya mencatat app yang dibuka lewat Auralys (tanpa izin Usage Access).
- Kategori memakai data kategori dari tiap app; banyak app tidak mengisinya (masuk "Other").
